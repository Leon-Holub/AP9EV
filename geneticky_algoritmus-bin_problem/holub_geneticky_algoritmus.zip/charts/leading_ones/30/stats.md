### leading_ones – D=30

| Selekce | best | worst | mean | median | std |
|---------|------|-------|------|--------|-----|
| roulette | 23.00 | 13.00 | 17.90 | 18.50 | 3.35 |
| rank | 27.00 | 14.00 | 20.70 | 21.50 | 3.92 |

| roulette | rank |
| --- | --- |
| ![roulette](roulette.png) | ![rank](rank.png) |
