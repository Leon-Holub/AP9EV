### leading_ones – D=100

| Selekce | best | worst | mean | median | std |
|---------|------|-------|------|--------|-----|
| roulette | 26.00 | 16.00 | 21.50 | 21.00 | 2.92 |
| rank | 29.00 | 18.00 | 22.30 | 21.00 | 3.40 |

| roulette | rank |
| --- | --- |
| ![roulette](roulette.png) | ![rank](rank.png) |
