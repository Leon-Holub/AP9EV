### onemax – D=100

| Selekce | best | worst | mean | median | std |
|---------|------|-------|------|--------|-----|
| roulette | 87.00 | 81.00 | 83.90 | 83.50 | 1.85 |
| rank | 94.00 | 90.00 | 91.90 | 92.00 | 1.10 |

| roulette | rank |
| --- | --- |
| ![roulette](roulette.png) | ![rank](rank.png) |
