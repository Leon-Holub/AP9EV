### onemax – D=30

| Selekce | best | worst | mean | median | std |
|---------|------|-------|------|--------|-----|
| roulette | 30.00 | 29.00 | 29.60 | 30.00 | 0.52 |
| rank | 30.00 | 30.00 | 30.00 | 30.00 | 0.00 |

| roulette | rank |
| --- | --- |
| ![roulette](roulette.png) | ![rank](rank.png) |
