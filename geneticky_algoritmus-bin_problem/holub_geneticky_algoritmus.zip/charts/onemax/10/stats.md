### onemax – D=10

| Selekce | best | worst | mean | median | std |
|---------|------|-------|------|--------|-----|
| roulette | 10.00 | 10.00 | 10.00 | 10.00 | 0.00 |
| rank | 10.00 | 10.00 | 10.00 | 10.00 | 0.00 |

| roulette | rank |
| --- | --- |
| ![roulette](roulette.png) | ![rank](rank.png) |
